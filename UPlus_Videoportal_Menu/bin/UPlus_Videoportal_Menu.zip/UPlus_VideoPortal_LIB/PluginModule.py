# -*- coding: utf-8 -*- 

'''
 This is Video Portal App Test API plug-in
'''
import os
import time
from datetime import datetime

from functools import wraps

from ATS.Plugins.ETA2ClientPlugin.ETA2ClientPlugin.ETA2ClientPlugin import ETA2ClientPlugin
from ATS.Core.Decorators import API, API2
from xml.dom import NOT_SUPPORTED_ERR

TIMEOUT_GUIDE_POPUP = 5000
DEV_GAL7 = "SM-G930S"  # 1440*2560
DEV_LGK430 = "LGK430"  #
DEVICE = DEV_GAL7

# 메인 화면 디폴트 메뉴 8개 변경
MAIN_DEFAULT_MENU = [[u"나의 무료", u"Menu-MyFree"], 
                     [u"실시간TV", u"Menu-RealTime TV"],
                     [u"TV다시보기", u"Menu-TV ReWatch"], 
                     [u"최신영화", u"Menu-New Movie"], 
                     [u"아프리카TV", u"Menu-New Movie"], 
                     [u"영화3만편", u"Menu-Movie 3Man"], 
                     [u"해외드라마", u"Menu-Overseas drama"], 
                     [u"스포츠TV", u"Menu-Sports TV"]
                    ] 

# 나의 무료 페이지에 구성된 하위 탭들. 좌측->우측 순서대로 기입할 것
MYFREE_SUBTAB = (u"무료혜택관", u"무료 채널", u"애니", u"아이들나라", u"다큐", u"영어", u"인문학 특강")

def stepResult(descriptionMsg=None):  
    def _stepResult(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if kwargs.get('deco') is False:
                func(*args, **kwargs)
            else:
                System.Debug(u"\n")
                strList = str(func).split()
                System.Debug(u"Step {} start: {}".format(strList[1], descriptionMsg))
                System.Debug(u"\n")            
                #System.Sleep(stepTimeout)    #for DEMO
                
                rc = func(*args, **kwargs)
                #DEV1._CaptureScreens()

                if rc not in [AT_SUCCESS, None]:
                    System.Finish(ExecutionResult.T_FAILED, u"Step {} fail: {}".format(strList[1], descriptionMsg))
                else:
                    System.Debug(u"\n")
                    System.Debug(u"Step {} succeed: {}".format(strList[1], descriptionMsg))
                    System.Debug(u"\n")
                    #System.Sleep(stepTimeout)    #for DEMO
        return wrapper
    return _stepResult


class ClientPlugin(ETA2ClientPlugin):
    count = 0
    
    def __init__(self, client, index, context):
        ETA2ClientPlugin.__init__(self, client, index, context) 
    
    @API()
    def LauchAppWithLoadingPage(self, bLoadingPage=True):
        # 앱이 실행되어 있을 경우, 종료시킴
        '''
        rc = self.AppForceStop('com.uplus.onphone')
        if rc != AT_SUCCESS:
            System.Debug("Video Portal Application is not found on device")
            return rc
        '''    
        if bLoadingPage == True:
            activity = 'com.uplus.onphone.page.LoadingPage'
        else:
            activity = 'com.uplus.onphone.activity.MainActivity'    
        
        rc, result = self.RunApplication('com.uplus.onphone', activity)   
        
        if rc != AT_SUCCESS:
            System.Debug("Video Portal Application is not found on device")
            return rc
        
        return AT_SUCCESS
   
    
    @API()
    def LauchApp(self):
        """
        :summary:
            VideoPortal 앱을 실행한다.
        """
        rc, result = self.RunApplication('com.uplus.onphone', 'com.uplus.onphone.page.LoadingPage')   
        
        if rc != AT_SUCCESS:
            System.Debug("Video Portal Application is not found on device")
            return rc
        
        return AT_SUCCESS  
    
    @API()
    def StopApp(self):
        """
        :summary:
            VideoPortal 앱을 중지한다.
        :note: 
            반복 테스트시 앱이 정상 종료되지 않는 경우가 있어
            작업 목록에 있는 모든 작업을 삭제하도록 구현함
        """
        
        
        rc = self.AppForceStop('com.uplus.onphone')
        if rc != AT_SUCCESS:
            System.Debug("Video Portal Application is not found on device")
            return rc
        
        
        rc = self.KeyPressByAlias('app_switch')   
        if rc != AT_SUCCESS:
            System.Debug('Could not press app_switch key')
            return rc 
        
        value = self.Context.Config.Mappings.values()
        model = value[0].Device.Model
        
        if model[0:2] == "LG":
            clickText = u"모두 지우기"
        elif model[0:2] == "SM":
            clickText = u"모두 닫기"
        else:
            System.Debug(u"LG 또는 Samsung 단말 아님")
            return AT_ERROR
        
        # 모두 닫기나 모두 지우기 버튼이 있는 경우 클릭
        rc, result = self.UIWaitForText(clickText, 2000)
        if result == True:
            rc = self.UIClickByText(clickText)
            if rc != AT_SUCCESS:
                System.Debug('Could not press all clear button')
                return rc           
        
        else:
            rc = self.KeyPressByAlias('back') 
            if rc != AT_SUCCESS:
                System.Debug('Could not press back button')
                return rc
       
        return AT_SUCCESS  
  
   
    @API()   
    def CheckLoadingPageShown(self, waitTimeout=3000):
        searchingObj = "splash_img"
        rc, result = self.UIWaitForName(searchingObj, waitTimeout)
    
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForName")
            return rc
             
        if result == False:
            System.Debug(u"Failed to find the object : "+searchingObj)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()    
    def CheckMainDisplayLoadedQC(self, waitTimeout=5000):
        
        searchingObj = "content"
        rc, result = self.UIWaitForName(searchingObj, waitTimeout)
    
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForName")
            return rc
             
        if result == False:
            System.Debug(u"Failed to find the object : "+searchingObj)
            return AT_NOT_FOUND
        
        return AT_SUCCESS  
    
    @API()    
    def CheckMainDisplayLoaded(self, waitTimeout=30000):
        """
        :summary:
            메인화면이 표시되었는지를 확인한다.
            상단의 비디오포털 타이틀과, 데이터도무료 아이콘이 나타났는지 여부로 판단하였음

        :param waitTimeout: 화면이 나타났는지 대기하는 최대대기시간
        :type  waitTimeout: integer (milliseconds)
        
        :returns: AT_SUCCESS:   찾고자 하는 화면 오브젝트들을 시간 내에 발견
                  AT_NOT_FOUND: 찾고자 하는 화면 오브젝트들을 시간 내에 발견하지 못함
                  그외 Return Code

        :see: :class:

        ::

            rc = DEV1.CheckMainDisplayLoaded()
            if rc != AT_SUCCESS:
                System.Debug(u"메인화면 찾기 실패")
                return rc

        """
        # 1.비디오 포털 타이틀 확인: type: avwImageView, name: fx_title_main, index: 0 
        
        searchingObj = "fx_title_main"
        rc, result = self.UIWaitForName(searchingObj, waitTimeout)
    
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForName")
            return rc
             
        if result == False:
            System.Debug(u"Failed to find the object : "+searchingObj)
            return AT_NOT_FOUND
              
        '''
        # 2. 검색 영역 표시 확인
        searchingObj = "fx_search_bar_bg"
        rc, result = self.UIWaitForName(searchingObj, waitTimeout)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForName")
            return rc
             
        if result == False:
            System.Debug(u"Failed to find the object : "+searchingObj)
            return AT_NOT_FOUND
        '''
       
        # 데이터도무료 아이콘 표시 확인  
        searchingText = u"실시간TV"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND        
        
        return AT_SUCCESS   
    
    @API()
    def CheckSearchButtonShown(self, waitTimeout=5000):
        '''
        메뉴 서브 홈 상단에 검색 버튼이 있는지를 체크한다
        '''
        searchingObj = "btn_search"
        rc, result = self.UIWaitForName(searchingObj, waitTimeout)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForName")
            return rc
             
        if result == False:
            System.Debug(u"Failed to find the object : "+searchingObj)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
       #################################################################
    # 메인화면의 서브 메뉴 클릭 관련 API
    #################################################################
    '''
    서브 메뉴 클릭 API 사용 예시 모음
    DEV1.ClickMyFreeMenu()
    
    DEV1.ClickDataFreeMenu()
   
    DEV1.ClickRealTimeTVWatchMenu()
 
    DEV1.ClickTVReWatchMenu()
   
    DEV1.ClickNewMovieMenu()
   
    DEV1.ClickMovie3ManMenu() 
   
    DEV1.ClickUplusBaseballMenu()
  
    DEV1.ClickSportsTVMenu()
      
    DEV1.ClickDaebakVideoMenu()
     
    DEV1.ClickForeignDramaMenu()
   
    DEV1.ClickAniMenu()
     
    DEV1.Click19Menu()
     
    DEV1.ClickOriginalSubtitleMenu()
    
    DEV1.ClickVideoCardMenu()
  
    DEV1.ClickSportsLessonMenu()
    
    DEV1.ClickHistoryVideoMenu()
     
    DEV1.ClickHumanBusinessMenu()
  
    DEV1.ClickDocuMenu()
    
    DEV1.ClickKidsWorldMenu()
      
    DEV1.Click360VideoMenu() 
    '''
    
    @API()
    def ClickMyFreeMenu(self):
        """
        :summary:
            나의 무료 메뉴를 클릭
        """
        return self.UIClickByText(u"나의 무료")
    
    @API()
    def ClickDataFreeMenu(self):
        """
        :summary:
            데이터도무료 메뉴를 클릭
        """
        return self.UIClickByText(u"데이터도무료")   
    
    @API()
    def ClickRealTimeTVWatchMenu(self):
        """
        :summary:
            실시간TV 메뉴를 클릭
        """
        # avwStaticText    fx_b1_title_03     실시간TV
        return self.UIClickByText(u"실시간TV")
    
   
    
    @API()
    def ClickNewMovieMenu(self):
        """
        :summary:
            최신영화 메뉴를 클릭
        """
        return self.UIClickByText(u"최신영화")  
    
    @API()
    def ClickMovie3ManMenu(self):
        """
        :summary:
            영화3만편 메뉴를 클릭
        """
        return self.UIClickByText(u"영화3만편")  
    
    @API()
    def ClickUplusBaseballMenu(self):
        """
        :summary:
            U+프로야구 메뉴를 클릭
        """
        return self.UIClickByText(u"U+프로야구")  
    
    @API()
    def ClickSportsTVMenu(self):
        """
        :summary:
            스포츠TV 메뉴를 클릭
        """
        return self.UIClickByText(u"스포츠TV")  
    
    @API()
    def ClickDaebakVideoMenu(self):
        """
        :summary:
            대박영상 메뉴를 클릭
        """
        return self.UIClickByText(u"대박영상") 
    
    
    @API()
    def ClickForeignDramaMenu(self):
        """
        :summary:
            해외드라마 메뉴를 클릭
        """
        return self.UIClickByText(u"해외드라마") 
    
    @API()
    def ClickAniMenu(self):
        """
        :summary:
            애니메이션 메뉴를 클릭
        """
        return self.UIClickByText(u"애니메이션") 
    
    @API()
    def Click19Menu(self):
        """
        :summary:
            19금 메뉴를 클릭
        """
        return self.UIClickByText(u"19금") 
    
    
    
    @API()
    def ClickOriginalSubtitleMenu(self):
        """
        :summary:
            원어자막 메뉴를 클릭
        """
        return self.UIClickByText(u"외국어")
    
    @API()
    def ClickVideoCardMenu(self):
        """
        :summary:
            영상카드 메뉴를 클릭
        """
        return self.UIClickByText(u"영상카드")
    
    @API()
    def ClickSportsLessonMenu(self):
        """
        :summary:
            스포츠강습 메뉴를 클릭
        """
        return self.UIClickByText(u"스포츠레슨")
    
    @API()
    def ClickHistoryVideoMenu(self):
        """
        :summary:
            시대별 영상 메뉴를 클릭
        """
        return self.UIClickByText(u"시대별 영상")
    
    @API()
    def ClickHumanBusinessMenu(self):
        """
        :summary:
            인문/경영 메뉴를 클릭
        """
        return self.UIClickByText(u"인문/경영")
    
    @API()
    def ClickDocuMenu(self):
        """
        :summary:
            다큐 메뉴를 클릭
        """
        return self.UIClickByText(u"다큐")
    
    @API()
    def ClickKidsWorldMenu(self):
        """
        :summary:
            아이들세상 를 클릭
        """
        return self.UIClickByText(u"아이들나라")
    
    @API()
    def Click360VideoMenu(self):
        """
        :summary:
            360도영상 를 클릭
        """
        return self.UIClickByText(u"360도영상") 
    
    
    #################################################################
    # 메인화면의 서브 메뉴 클릭시 서브 메뉴 화면이 표시되었는지 확인
    #################################################################
    '''
     서브 메뉴 화면 체크 API 사용 예시 모음
    DEV1.CheckMyFreeMenuSubHomeShown()
    
    DEV1.CheckDataFreeMenuSubHomeShown()
   
    DEV1.CheckRealTimeTVWatchMenuSubHomeShown()
 
    DEV1.CheckTVReWatchMenuSubHomeShown()
   
    DEV1.CheckNewMovieMenuSubHomeShown()
   
    DEV1.CheckMovie3ManMenuSubHomeShown() 
   
    DEV1.CheckUplusBaseballMenuSubHomeShown()
  
    DEV1.CheckSportsTVMenuSubHomeShown()
      
    DEV1.CheckDaebakVideoMenuSubHomeShown()
     
    DEV1.CheckForeignDramaMenuSubHomeShown()
   
    DEV1.CheckAniMenuSubHomeShown()
     
    DEV1.Check19MenuSubHomeShown()
     
    DEV1.CheckOriginalSubtitleMenuSubHomeShown()
    
    DEV1.CheckVideoCardMenuSubHomeShown()
  
    DEV1.CheckSportsLessonMenuSubHomeShown()
    
    DEV1.CheckHistoryVideoMenuSubHomeShown()
     
    DEV1.CheckHumanBusinessMenuSubHomeShown()
  
    DEV1.CheckDocuMenuSubHomeShown()
    
    DEV1.CheckKidsWorldMenuSubHomeShown()
      
    DEV1.Check360VideoMenuSubHomeShown() 
    '''
    
    @API()
    def CheckMyFreeMenuSubHomeShown(self, waitTimeout=5000):
        """
        :summary:
            나의 무료 메뉴 서브홈이 표시되었는지 확인
        """
        searchingText = u"무료혜택관"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        searchingText = u"나의 무료"
        rc, result = self.UIWaitForText(searchingText, 100, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def CheckDataFreeMenuSubHomeShown(self, waitTimeout=5000):
        """
        :summary:
            데이터도무료 메뉴 서브홈이 표시되었는지 확인
        """
        searchingText = u"U+고객은 데이터도 무료"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS 
    
    @API()
    def CheckRealTimeTVWatchMenuSubHomeShown(self, waitTimeout=5000):
        """
        :summary:
            실시간TV 메뉴 서브홈이 표시되었는지 확인
        """
        
        # 타이틀 왼쪽에 있는 집 모양 Object 찾기
        searchingObj = "btn_gotomain"
        rc, result = self.UIWaitForName(searchingObj, waitTimeout)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForName")
            return rc
             
        if result == False:
            System.Debug(u"Failed to find the object : "+searchingObj)
            return AT_NOT_FOUND
        
        searchingText = u"실시간 TV"
        rc, result = self.UIWaitForText(searchingText, 100, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS 
    
    @API()
    def CheckTVReWatchMenuSubHomeShown(self, waitTimeout=5000):
        """
        :summary:
            TV다시보기 메뉴 서브홈이 표시되었는지 확인
        """
        # 이전 화면 "TV다시보기" 아이콘과 서브 메뉴 홈의 "TV다시보기" 타이틀의 텍스트가 동일함.
        # "TV다시보기" 텍스트로 체크할 경우, 이전 화면이 남아있는 건지, 화면이 전환된건지 알 수 없으므로
        # 화면 전환을 체크할 수 있는 다른 텍스트로 체크
        searchingText = u"최신 인기 방송"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        
        searchingText = u"TV다시보기"
        rc, result = self.UIWaitForText(searchingText, 100, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def CheckNewMovieMenuSubHomeShown(self, waitTimeout=5000):
        """
        :summary:
            최신영화 메뉴 서브홈이 표시되었는지 확인
        """
        searchingText = u"영화"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        searchingText = u"인기"
        rc, result = self.UIWaitForText(searchingText, 100, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS  
    
    @API()
    def CheckMovie3ManMenuSubHomeShown(self, waitTimeout=5000):
        """
        :summary:
            영화3만편 메뉴 서브홈이 표시되었는지 확인
        """
        searchingText = u"U+영화월정액(Uflix)"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS  
    
    @API()
    def CheckUplusBaseballMenuSubHomeShown(self, waitTimeout=5000):
        """
        :summary:
            U+프로야구 메뉴 서브홈이 표시되었는지 확인
        """
        
        # 타이틀 왼쪽에 있는 집 모양 Object 찾기
        """searchingObj = "btn_gotomain"
        rc, result = self.UIWaitForName(searchingObj, waitTimeout)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForName")
            return rc
             
        if result == False:
            System.Debug(u"Failed to find the object : "+searchingObj)
            return AT_NOT_FOUND"""
        
        
        searchingText = u"U+프로야구"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS  
    
    @API()
    def CheckSportsTVMenuSubHomeShown(self, waitTimeout=5000):
        """
        :summary:
            스포츠TV 메뉴 서브홈이 표시되었는지 확인
        """
        searchingText = u"경기일정"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        searchingText = u"스포츠TV"
        rc, result = self.UIWaitForText(searchingText, 100, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def CheckDaebakVideoMenuSubHomeShown(self, waitTimeout=5000):
        """
        :summary:
            대박영상 메뉴 서브홈이 표시되었는지 확인
        """
        searchingText = u"인기영상"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        searchingText = u"대박영상"
        rc, result = self.UIWaitForText(searchingText, 100, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    
    @API()
    def CheckForeignDramaMenuSubHomeShown(self, waitTimeout=5000):
        """
        :summary:
            해외드라마 메뉴 서브홈이 표시되었는지 확인
        """
        searchingText = u"미드/영드"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        searchingText = u"해외드라마"
        rc, result = self.UIWaitForText(searchingText, 100, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def CheckForeignDramaMenu(self, waitTimeout=5000):
        """
        :summary:
            해외드라마 메뉴에 표시되었는지 확인
        """
        
        searchingText = u"해외드라마"
        rc, result = self.UIWaitForText(searchingText, 100, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def CheckForeignDramaMenuSubHomeShownQC(self, waitTimeout=5000):
        """
        :summary:
            해외드라마 메뉴 서브홈이 표시되었는지 확인
        """
        searchingText = u"미드/영드"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        """searchingText = u"해외드라마"
        rc, result = self.UIWaitForText(searchingText, 100, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND"""
        
        return AT_SUCCESS
    
    @API()
    def CheckAniMenuSubHomeShown(self, waitTimeout=5000):
        """
        :summary:
            애니메이션 메뉴 서브홈이 표시되었는지 확인
        """
        # 아이들세상 서브 홈에도 캐릭터관이라는 텍스트가 존재하므로
        # 캐릭터관, 애니메이션 두개의 텍스트가 모두 있는지 체크
        """searchingText = u"캐릭터관"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND"""
        
        
        searchingText = u"애니메이션"
        rc, result = self.UIWaitForText(searchingText, 100, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def Check19MenuSubHomeShown(self, waitTimeout=5000):
        """
        :summary:
            19금 메뉴 서브홈이 표시되었는지 확인
        """
        searchingText = u"한국관"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
    
        searchingText = u"일본관"
        rc, result = self.UIWaitForText(searchingText, 100, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS   
    
    @API()
    def CheckOriginalSubtitleMenuSubHomeShown(self, waitTimeout=5000):
        """
        :summary:
            원어자막 메뉴 서브홈이 표시되었는지 확인
        """
        searchingText = u"영어자막"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        searchingText = u"외국어"
        rc, result = self.UIWaitForText(searchingText, 100, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def CheckVideoCardMenuSubHomeShown(self, waitTimeout=5000):
        """
        :summary:
            영상카드 메뉴 서브홈이 표시되었는지 확인
        """
        searchingText = u"홈"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        searchingText = u"영상카드"
        rc, result = self.UIWaitForText(searchingText, 100, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def CheckSportsLessonMenuSubHomeShown(self, waitTimeout=5000):
        """
        :summary:
            스포츠강습 메뉴 서브홈이 표시되었는지 확인
        """
        searchingText = u"골프"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        searchingText = u"스포츠레슨"
        rc, result = self.UIWaitForText(searchingText, 100, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def CheckHistoryVideoMenuSubHomeShown(self, waitTimeout=5000):
        """
        :summary:
            시대별 영상 메뉴 서브홈이 표시되었는지 확인
        """
        searchingText = u"한국사"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        searchingText = u"시대별 영상"
        rc, result = self.UIWaitForText(searchingText, 100, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def CheckHumanBusinessMenuSubHomeShown(self, waitTimeout=5000):
        """
        :summary:
            인문/경영 메뉴 서브홈이 표시되었는지 확인
        """
        searchingText = u"지식채널e"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        searchingText = u"인문/경영"
        rc, result = self.UIWaitForText(searchingText, 100, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def CheckDocuMenuSubHomeShown(self, waitTimeout=5000):
        """
        :summary:
            다큐 메뉴 서브홈이 표시되었는지 확인
        """
        searchingText = u"명품다큐"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def CheckKidsWorldMenuSubHomeShown(self, waitTimeout=5000):
        """
        :summary:
            아이들세상 메뉴 서브홈이 표시되었는지 확인
        """
        """
        searchingText = u"zoflr"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        """
        
        searchingText = u"아이들나라"
        rc, result = self.UIWaitForText(searchingText, 100, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
    
    @API()
    def Check360VideoMenuSubHomeShown(self, waitTimeout=5000):
        """
        :summary:
            360도영상 메뉴 서브홈이 표시되었는지 확인
        """
        searchingText = u"베스트VR"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        searchingText = u"360도영상"
        rc, result = self.UIWaitForText(searchingText, 100, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    






    '''
    @API()
    def ClickRealTimeTVWatchMenu(self):
        """
        :summary:
            실시간TV 메뉴를 클릭
        """
        # avwStaticText    fx_b1_title_03     실시간TV
        return self.UIClickByText("실시간TV")
    '''
    # No Reference
    @API()
    def CheckRealTimeTVWatchTitleShown(self, waitTimeout=3000):
        """
        :summary:
            실시간TV 타이틀이 표시되었는지 확인
        """
        # type            name        text
        # avwStaticText   tv_title    실시간 TV
        searchingObj = "tv_title"
        rc, result = self.UIWaitForName(searchingObj, waitTimeout)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForName")
            return rc
             
        if result == False:
            System.Debug(u"Failed to find the object : "+searchingObj)
            return AT_NOT_FOUND
        
        return AT_SUCCESS   
    
    # No Reference
    @API()
    def SetRealTimeTVWatchFullScreen(self):
        """
        :summary:
            실시간TV 화면의 재생 화면을 클릭
        """
        # type            name      
        # avwSubWindow,   playerView,  
        return self.UIClickByName('playerView', 0, UITarget.TopWindow)
    
    # No Reference                                                                                     
    @API()
    def CheckDataNetworkUsagePopup(self):
        findText = u"데이터 네트워크 사용 안내"
        rc, result = self.UIWaitForText(findText, Timeout.WAIT_POPUP, 0, UITarget.TopWindow)
    
    @API()
    def CheckMainMenuGNB(self, waitTimeout=3000):
        """
        :summary:
            GNB 메뉴 확인
        """
        searchingObj = "fx_title_menu"
        rc, result = self.UIWaitForName(searchingObj, waitTimeout)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForName")
            return rc
             
        if result == False:
            System.Debug(u"Failed to find the object : "+searchingObj)
            return AT_NOT_FOUND
        
        return AT_SUCCESS   
    
    @API()
    def ClickMainMenuGNB(self):
        """
        :summary:
            GNB 메뉴 클릭
        """
        return self.UIClickByName('fx_title_menu', 0, UITarget.TopWindow)
    
    @API()
    def FlickGNBMenuOpen(self):
        """
        :summary:
            메인 화면에서 우-> 좌 Flicking 수행 (GNB 메뉴 오픈하기 위함)
        """
        if DEVICE == DEV_LGK430: # LGK430
            rc = DEV1.TouchSlide(700, 640, 400, 640, 10, 10)
        elif DEVICE == DEV_GAL7:                    # SM-G930S (Galaxy 7)
            rc = DEV1.TouchSlide(1400, 640, 700, 640, 10, 10) 
        else:
            rc = NOT_SUPPORTED_ERR
        
        return rc
    
    @API()
    def GetModelNamePrefix(self):
        value = self.Context.Config.Mappings.values()
        model = value[0].Device.Model
        
        if model[0:2] == "LG" or model[0:2] == "SM":
            return model[0:2]
        else:
            System.Debug("No LG or Samsung device")
            return "etc"
        
    
    @API()
    def CheckMainMenuGNBLoaded(self):
        """
        :summary:
            GNB 메뉴 화면이 표시되었는지 확인한다.
            화면 표시 여부는 "MY비디오"와 "많이 본 장르/키워드" 텍스트 표시 여부로 판단하였음
        """
        
        # type: avwStaticText, name: gnb_myvideo_heading, text: MY비디오
        searchingText = u"MY비디오"
        rc, result = self.UICheckTextByType("avwStaticText", searchingText)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UICheckTextByType")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        # 0424 체크 항목 추가
        # type            name                   text
        # avwStaticText   gnb_waching_analysis   많이 본 장르/키워드
        searchingText = u"많이 본 장르/키워드"
        rc, result = self.UIWaitForText(searchingText, 2000, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
   
    @API()
    def CheckMyVideoTitle(self, waitTimeout=15000):
        '''
        MY 비디오 텍스트가 나타났는지 체크한다
        
        본 API 호출 전 예상 Action: GNB 메뉴 탭 -> MY비디오 옆 전체보기 탭
        '''
        
        # type: avwStaticText, name: text_title, text: MY 비디오
        '''
        searchingObj = 'text_title'
        rc, result = self.UIWaitForName(searchingObj, waitTimeout)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForName")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the object : "+searchingObj)
            return AT_NOT_FOUND
        '''
        # 0424 텍스트 타입으로 찾도록 변경
        searchingText = u"MY 비디오"
        rc, result = self.UIWaitForText(searchingText, waitTimeout)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def ClickMyVideoTitle(self):
        return self.UIClickByName('text_title', 0, UITarget.TopWindow)
    
    
    @API2()
    def CheckLogInState(self):
        '''
        GNB Tab을 눌러 로그인 상태를 확인한다.
          비로그인상태: 로그인 안내 문구가 보임
          로그인  상태: 계정정보 텍스트가 보임
        
        정상적으로 체크 완료시 GNB Tab이 열려져 있는 상태로 종료함
        '''
        rc = self.LauchApp()
        if rc != AT_SUCCESS:
            return rc, rc
        
        rc = self.CheckMainDisplayLoaded()
        if rc != AT_SUCCESS:
            return rc, rc
        
        rc = self.ClickMainMenuGNB()
        if rc != AT_SUCCESS:
            return rc, rc
        
        rc = self.CheckMainMenuGNBLoaded()
        if rc != AT_SUCCESS:
            return rc, rc
            
        # 비 로그인 상태인지 확인
        searchingText = u"로그인 하세요."
        rc, result = self.UIWaitForText(searchingText, 2000)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc, rc
        
        if result == True:
            System.Debug("비로그인 상태임")
            return rc, False
        else: 
            # 계정정보가 표시되면 로그인 상태
            #   type: avwStaticText, name: gnb_profile_info, text: 계정정보
            searchingText = u"계정정보"
            rc, result = self.UIWaitForText(searchingText, 1000)
            if rc != AT_SUCCESS:
                System.Debug(u"Failed to UIWaitForText")
                return rc, rc
            
            if result == True:
                System.Debug("로그인 상태임")
                return rc, True
        
        return AT_SUCCESS
    
    @API()
    def ClickLoginButtonOnGNB(self):
        # avwSubWindow, ly_profile_login_btn, 9085
        return self.UIClickByName('ly_profile_login_btn', 0, UITarget.TopWindow)
    
    @API()
    def CheckLogInDisplayShown(self):
        """
        :summary:
            로그인 화면(ID와 PW 입력화면)이 표시되었는지 확인한다
        """
        # ID 입력 object의 description 찾기
        rc, result = self.UIWaitForDescription(u"ONE ID (이메일) / LTE비디오포털 ID", 15000)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForDescription")
            return rc
        if not result:
            return AT_NOT_FOUND
        
        return AT_SUCCESS        

    @API()
    def ClickProfileInfo(self):
        """
        :summary:
            GNB 메뉴의 계정정보 클릭
        """
        return self.UIClickByName('gnb_profile_info', 0, UITarget.TopWindow)
    
    @API()
    def ClickLogOut(self):  
        """
        :summary:
            GNB 메뉴의 계정정보 > 로그아웃 클릭
        """  
         # type: avwImageButton, name: idLogoutBtn, index: 9001
        return self.UIClickByName('idLogoutBtn', 0, UITarget.TopWindow)
    

    ###################################
    # 검색 관련 API
    ###################################
    
    @API()
    def CheckMainMenuSearch(self, waitTimeout=15000):
        """
        :summary:
            검색버튼 표시되었는지 확인
        """ 
        # type:avwEdit,   name:search_input_keyword
        searchingObj = 'fx_title_search'
        rc, result = self.UIWaitForName(searchingObj, waitTimeout)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForName")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the object : "+searchingObj)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def ClickMainMenuSearchArea(self):
        """
        :summary:
            메인화면의 검색영역 클릭
        """ 
        return self.UIClickByName('fx_title_search', 0, UITarget.TopWindow)
      
    @API()
    def CheckMainMenuSearchLoaded(self, waitTimeout=15000):
        """
        :summary:
            검색창이 표시되었는지 확인
        """ 
        # type:avwEdit,   name:search_input_keyword
        searchingObj = 'search_input_keyword'
        rc, result = self.UIWaitForName(searchingObj, waitTimeout)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForName")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the object : "+searchingObj)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def SetSearchText(self, searchingText):
        """
        :summary:
            검색창에서 검색어 입력 부분에 검색어 입력
        """
        return self.UISetTextByName('search_input_keyword', searchingText, True)   
    
    @API()
    def ClickSearchButton(self):    
        """
        :summary:
            검색창에서 검색버튼(돋보기모양) 클릭
        """
        return self.UIClickByName('search_button', 0, UITarget.TopWindow)       
    
    @API()
    def CheckSearchResultShown(self, waitTimeout=10000):
        """
        :summary:
            검색결과화면이 나타났는지 확인
        """
        # 정확도순 radio 버튼
        # avwRadioButton    search_result_sort_accuracy_btn   정확도순
        searchingObj = 'search_result_sort_accuracy_btn'
        rc, result = self.UIWaitForName(searchingObj, waitTimeout)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForName")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the object : "+searchingObj)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    
    ###################################
    # 메뉴 관련 API
    ###################################
    @API()
    def CheckMoreMenuShown(self, waitTimeout=5000):
        """
        :summary:
            [더보기] 버튼이 나타났는지 확인
        """
        searchingObj = 'fx_b1_more_expand'
        rc, result = self.UIWaitForName(searchingObj, waitTimeout)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForName")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the object : "+searchingObj)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def ClickMoreMenu(self):
        """
        :summary:
            [더보기] 버튼 클릭
        """
        # type: avwSubWindow
        # name: fx_b1_more_expand
        # index: 39
        return self.UIClickByName('fx_b1_more_expand', 0, UITarget.TopWindow)
    
    @API()
    def CheckMenuEditShown(self, waitTimeout=5000):
        """
        :summary:
            [메뉴편집] 버튼이 나타났는지 확인
        """
        # type: avwSubWindow
        # name: fx_b1_setting
        # index: 50
        searchingObj = 'fx_b1_setting'
        rc, result = self.UIWaitForName(searchingObj, waitTimeout)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForName")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the object : "+searchingObj)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def ClickMenuEdit(self):
        """
        :summary:
            [메뉴편집] 버튼 클릭
        """
        return self.UIClickByName('fx_b1_setting', 0, UITarget.TopWindow)
    
    
    @API()
    def CheckMenuCloseShown(self, waitTimeout=5000):      
        """
        :summary:
            메뉴에 대해 [닫기] 버튼이 나타났는지 확인
        """
        # type: avwSubWindow
        # name: fx_b1_setting
        # index: 50
        
        searchingObj = 'fx_b1_more_shrink'
        rc, result = self.UIWaitForName(searchingObj, waitTimeout)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForName")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the object : "+searchingObj)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def ClickMenuClose(self):
        """
        :summary:
            [닫기] 버튼 클릭
        """
        return self.UIClickByName('fx_b1_more_shrink', 0, UITarget.TopWindow)



    
    @API()    
    def ClickPersonlSetting(self):
        """
        :summary:
            메인화면의 설정 버튼 클릭
        """
        # type: avwImageButton
        # name: fx_title_personal_setting
        # index: 0
        return self.UIClickByName('fx_title_personal_setting', 0, UITarget.TopWindow)
    
    @API()
    def CheckPersonalSettingDisplayShown(self, waitTimeout=10000):
        """
        :summary:
            설정 화면 나타났는지 확인
        """
        
        # 이전 화살표 체크
        #  type: avwImageView
        #  name: img_back
        #  index: 0
        searchingObj = 'img_back'
        rc, result = self.UIWaitForName(searchingObj, waitTimeout)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForName")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the object : "+searchingObj)
            return AT_NOT_FOUND
              
        # 설정 Text 체크
        searchingText = u"설정"
        rc, result = self.UICheckTextByType("avwStaticText", searchingText)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UICheckTextByType")
            return rc
        
        if result != True:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def ClickStarRating(self):
        """
        :summary:
            영화/드라마 별점주기 클릭
        """
        return self.UIClickByName('star_rating_run', 0, UITarget.TopWindow)
        # return self.UIClickByText(u'영화/드라마 별점주기', 0, UITarget.TopWindow)
               
    
    @API()
    def CheckStarRatingShown(self, waitTimeout=10000):
        """
        :summary:
            영화/드라마 별점주기 텍스트가 표시되었는지 확인
        """
        searchingText = u"영화/드라마 별점주기"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def CheckStarRatingBarShown(self, waitTimeout=10000):
        """
        :summary:
            별점 평가할 별 모양이 표시되었는지 확인
        """
        searchingObj = 'contents_rating_bar'
        rc, result = self.UIWaitForName(searchingObj, waitTimeout)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForName")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the object : "+searchingObj)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def CheckStarOneTen(self, waitTimeout=10000):
        """
        :summary:
            별점 평가 1~10점 텍스트까지 모두 확인 
        """
        # 첫 반쪽 별 좌표얻어오기
        rc, result = self.UIGetObjectByTypeIndex('avwImageView', 9003)
        if rc != AT_SUCCESS:
            return rc
    
        xFrom, yFrom = result.GetCenterCoords()
        
        rc = self.TouchScreen(xFrom-20, yFrom)
        if rc != AT_SUCCESS:
            System.Debug(u"Impossible to drag the screen control")
            return rc
        
        STR_NM = u"1점! 재미없어요"
        rc, result = self.UIWaitForText(STR_NM, 3000)
        if rc != AT_SUCCESS:  # API가 성공적으로 수행되었는지 확인
            return rc
        
        if result == False:   # 텍스트가 나타났는지 확인
            return AT_NOT_FOUND
        
        # 첫번째 완벽 별 좌표얻어오기
        rc, result = self.UIGetObjectByTypeIndex('avwImageView', 9003)
        if rc != AT_SUCCESS:
            return rc
    
        xFrom, yFrom = result.GetCenterCoords()
        
        rc = self.TouchScreen(xFrom+50, yFrom)
        if rc != AT_SUCCESS:
            System.Debug(u"Impossible to drag the screen control")
            return rc
        
        
        STR_NM = u"2점! 재미없어요"
        rc, result = self.UIWaitForText(STR_NM, 3000)
        if rc != AT_SUCCESS:  # API가 성공적으로 수행되었는지 확인
            return rc
        
        if result == False:   # 텍스트가 나타났는지 확인
            return AT_NOT_FOUND
        
        # 두번째 반쪽 완벽 별 좌표얻어오기
        rc, result = self.UIGetObjectByTypeIndex('avwImageView', 9004)
        if rc != AT_SUCCESS:
            return rc
    
        xFrom, yFrom = result.GetCenterCoords()
        
        rc = self.TouchScreen(xFrom-5, yFrom)
        if rc != AT_SUCCESS:
            System.Debug(u"Impossible to drag the screen control")
            return rc
        
        STR_NM = u"3점! 생각보다 별로"
        rc, result = self.UIWaitForText(STR_NM, 3000)
        if rc != AT_SUCCESS:  # API가 성공적으로 수행되었는지 확인
            return rc
        
        if result == False:   # 텍스트가 나타났는지 확인
            return AT_NOT_FOUND

        # 두번째 완벽 별 좌표얻어오기
        rc, result = self.UIGetObjectByTypeIndex('avwImageView', 9004)
        if rc != AT_SUCCESS:
            return rc
    
        xFrom, yFrom = result.GetCenterCoords()
        
        rc = self.TouchScreen(xFrom+50, yFrom)
        if rc != AT_SUCCESS:
            System.Debug(u"Impossible to drag the screen control")
            return rc
        
        
        STR_NM = u"4점! 생각보다 별로"
        rc, result = self.UIWaitForText(STR_NM, 3000)
        if rc != AT_SUCCESS:  # API가 성공적으로 수행되었는지 확인
            return rc
        
        if result == False:   # 텍스트가 나타났는지 확인
            return AT_NOT_FOUND
        
        # 세번째 반쪽 완벽 별 좌표얻어오기
        rc, result = self.UIGetObjectByTypeIndex('avwImageView', 9005)
        if rc != AT_SUCCESS:
            return rc
    
        xFrom, yFrom = result.GetCenterCoords()
        
        rc = self.TouchScreen(xFrom-5, yFrom)
        if rc != AT_SUCCESS:
            System.Debug(u"Impossible to drag the screen control")
            return rc
        
        
        STR_NM = u"5점! 보통이네요"
        rc, result = self.UIWaitForText(STR_NM, 3000)
        if rc != AT_SUCCESS:  # API가 성공적으로 수행되었는지 확인
            return rc
        
        if result == False:   # 텍스트가 나타났는지 확인
            return AT_NOT_FOUND
        
        # 세번째 완벽 별 좌표얻어오기
        rc, result = self.UIGetObjectByTypeIndex('avwImageView', 9005)
        if rc != AT_SUCCESS:
            return rc
    
        xFrom, yFrom = result.GetCenterCoords()
        
        rc = self.TouchScreen(xFrom+50, yFrom)
        if rc != AT_SUCCESS:
            System.Debug(u"Impossible to drag the screen control")
            return rc
        
        
        STR_NM = u"6점! 보통이네요"
        rc, result = self.UIWaitForText(STR_NM, 3000)
        if rc != AT_SUCCESS:  # API가 성공적으로 수행되었는지 확인
            return rc
        
        if result == False:   # 텍스트가 나타났는지 확인
            return AT_NOT_FOUND
        
        # 네번째 반쪽 완벽 별 좌표얻어오기
        rc, result = self.UIGetObjectByTypeIndex('avwImageView', 9006)
        if rc != AT_SUCCESS:
            return rc
    
        xFrom, yFrom = result.GetCenterCoords()
        
        rc = self.TouchScreen(xFrom-5, yFrom)
        if rc != AT_SUCCESS:
            System.Debug(u"Impossible to drag the screen control")
            return rc
        
        
        STR_NM = u"7점! 괜찮네요!재미있어요"
        rc, result = self.UIWaitForText(STR_NM, 3000)
        if rc != AT_SUCCESS:  # API가 성공적으로 수행되었는지 확인
            return rc
        
        if result == False:   # 텍스트가 나타났는지 확인
            return AT_NOT_FOUND
        
        # 네번째 완벽 별 좌표얻어오기
        rc, result = self.UIGetObjectByTypeIndex('avwImageView', 9006)
        if rc != AT_SUCCESS:
            return rc
    
        xFrom, yFrom = result.GetCenterCoords()
        
        rc = self.TouchScreen(xFrom+50, yFrom)
        if rc != AT_SUCCESS:
            System.Debug(u"Impossible to drag the screen control")
            return rc
        
        
        STR_NM = u"8점! 괜찮네요!재미있어요"
        rc, result = self.UIWaitForText(STR_NM, 3000)
        if rc != AT_SUCCESS:  # API가 성공적으로 수행되었는지 확인
            return rc
        
        if result == False:   # 텍스트가 나타났는지 확인
            return AT_NOT_FOUND
        
        # 다섯번째 반쪽 완벽 별 좌표얻어오기
        rc, result = self.UIGetObjectByTypeIndex('avwImageView', 9007)
        if rc != AT_SUCCESS:
            return rc
    
        xFrom, yFrom = result.GetCenterCoords()
        
        rc = self.TouchScreen(xFrom-5, yFrom)
        if rc != AT_SUCCESS:
            System.Debug(u"Impossible to drag the screen control")
            return rc
        
        
        STR_NM = u"9점! 강추!재미있습니다"
        rc, result = self.UIWaitForText(STR_NM, 3000)
        if rc != AT_SUCCESS:  # API가 성공적으로 수행되었는지 확인
            return rc
        
        if result == False:   # 텍스트가 나타났는지 확인
            return AT_NOT_FOUND
        
        # 다섯번째 완벽 별 좌표얻어오기
        rc, result = self.UIGetObjectByTypeIndex('avwImageView', 9007)
        if rc != AT_SUCCESS:
            return rc
    
        xFrom, yFrom = result.GetCenterCoords()
        
        rc = self.TouchScreen(xFrom+50, yFrom)
        if rc != AT_SUCCESS:
            System.Debug(u"Impossible to drag the screen control")
            return rc
        
        STR_NM = u"10점! 강추!재미있습니다"
        rc, result = self.UIWaitForText(STR_NM, 3000)
        if rc != AT_SUCCESS:  # API가 성공적으로 수행되었는지 확인
            return rc
        
        if result == False:   # 텍스트가 나타났는지 확인
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
   
    @API()
    def CheckStarOneTwo(self, waitTimeout=10000):
        """
        :summary:
            별점 평가 1~10점 텍스트까지 모두 확인 
        """
        # 첫 반쪽 별 좌표얻어오기
        rc, result = self.UIGetObjectByTypeIndex('avwImageView', 9003)
        if rc != AT_SUCCESS:
            return rc
    
        xFrom, yFrom = result.GetCenterCoords()
        
        rc = self.TouchScreen(xFrom-5, yFrom)
        if rc != AT_SUCCESS:
            System.Debug(u"Impossible to drag the screen control")
            return rc
        
        
        STR_NM = u"1점! 재미없어요"
        rc, result = self.UIWaitForText(STR_NM, 3000)
        if rc != AT_SUCCESS:  # API가 성공적으로 수행되었는지 확인
            return rc
        
        if result == False:   # 텍스트가 나타났는지 확인
            return AT_NOT_FOUND
        
        # 첫번째 완벽 별 좌표얻어오기
        rc, result = self.UIGetObjectByTypeIndex('avwImageView', 9003)
        if rc != AT_SUCCESS:
            return rc
    
        xFrom, yFrom = result.GetCenterCoords()
        
        rc = self.TouchScreen(xFrom+50, yFrom)
        if rc != AT_SUCCESS:
            System.Debug(u"Impossible to drag the screen control")
            return rc
        
        
        STR_NM = u"2점! 재미없어요"
        rc, result = self.UIWaitForText(STR_NM, 3000)
        if rc != AT_SUCCESS:  # API가 성공적으로 수행되었는지 확인
            return rc
        
        if result == False:   # 텍스트가 나타났는지 확인
            return AT_NOT_FOUND
        
        
        return AT_SUCCESS
    
       
    @API()
    def CheckTVReWatchMenuShown(self, waitTimeout=5000):
        """
        :summary:
            TV다시보기 메뉴가 표시되었는지 확인
        """
        searchingText = u"TV다시보기"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def ClickTVReWatchMenu(self):
        """
        :summary:
            TV다시보기 메뉴 클릭
        """
        return self.UIClickByText(u"TV다시보기")
    
    @API()
    def CheckTVReWatchDisplayShown(self, waitTimeout=5000):
        """
        :summary:
            TV다시보기 서브 홈 표시되었는지 확인
        """
      
        # 최신 인기 방송 텍스트 체크
        '''
        Note:
        서브 홈의 제목에는 TV다시보기 텍스트가 표시되어 있지만, 이 텍스트를 확인하지 않았음
        직전에 TV다시보기 메뉴의 텍스트를 클릭하고, 다시 TV다시보기 텍스트가 나타났는지를 확인할 경우
        실제로는 화면이 전환되지 않았으나 현재 화면에 해당 텍스트가 있어서 참이 될 수 있다.
        '''
        searchingText = u"최신 인기 방송"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    @API()
    def CheckBaseballShown(self, waitTimeout=8000):
        """
        :summary:
            프로야수 서브 홈 표시되었는지 확인
        """
      
        # 최신 인기 방송 텍스트 체크
        
        searchingText = u"U+프로야구"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
        
    @API()
    def SetWifiAndDataTransfer(self, bWifiOn, bDataTransferOn):
        """
        :summary:
            Wifi On/off와 Data On/off 설정
            
        :param bWifiOn: Wifi On 여부. True: On, False: Off
        :type  bWifiOn: boolean
        
        :param bDataTransferOn: Data On 여부. True: On, False: Off
        :type  bDataTransferOn: boolean
        """
        # For only LG
        rc = self.SetState(State.WiFi, bWifiOn)
        if rc != AT_SUCCESS:
            return rc
        
        rc = self.SetState(State.DataTransfer, bDataTransferOn)
        if rc != AT_SUCCESS:
            return rc
        
        System.Sleep(10000)
         
        rc, ps = self.GetPhoneState()
        if rc != AT_SUCCESS:
            return rc
        
        System.Debug("wifi: [%s] DataTransferOn: [%s]"%(str(ps.IsWifiOn), str(ps.IsDataTransferOn)))
        
        if ps.IsWifiOn == bWifiOn and ps.IsDataTransferOn == bDataTransferOn:
            return AT_SUCCESS
        else:
            return AT_ERROR           
    
    # No Reference
    @API()
    def CheckDataNetworkConnectionNOKPopup(self, waitTimeout=7000):
        
        System.Sleep(5000)
        expectedMsg = u"네트워크 연결불가 상태입니다.\n네트워크 설정에서 Wi-Fi에 연결 하시거나, 모바일 데이터 접속 허용상태로 변경 후 사용하시기 바랍니다.\n다운로드 목록에 다운받은 컨텐츠는 네트워크 상태와 상관없이 이용하실 수 있습니다."
        rc, result = self.UIGetPropertyByTypeIndex("avwStaticText", 9001, 'text')
         
       
        System.Debug(result)

        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIGetPropertyByTypeIndex")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        if result != expectedMsg:
            return AT_ERROR
        
        return AT_SUCCESS

    
    @API()
    def CheckDataNetworkUsageGuidePopup(self, waitTimeout=5000):    
        """
        :summary: 
            데이터 네트워크 사용 안내 팝업 표시 확인 
        """  
        searchingText = u"3G/LTE 망으로 이용 시 데이터 통화료는 가입하신 요금제에 따라 차감/부과됩니다.\n3G로 연결된 경우 영상 화질이 낮을 수 있습니다."
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            #System.Debug(u"Failed to UIGetPropertyByTypeIndex")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def UIWaitForToastPopup(self, text, searchingObj='message', waitTimeout = 100):
        """
        :summary:
                 토스트 팝업 메시지가 나타나기를 기다린다.

        :param text: 팝업 메시지에 표시되는 텍스트
        :type  text: str
        
        :param searchingObj: 찾을 오브젝트 명. 'message'는 Toast Popup object에 대한 이름임 
        :type  searchingObj: str

        :param waitTimeout: Timeout of waiting in milliseconds
        :type  waitTimeout: int

        :returns: AT_UI_CONTROL_NOT_FOUND if the target control has not been found by specified objType and index.
                  AT_NOT_FOUND, None if the specified property is absent

        :see: :class:`ReturnCode <Core.Enums.ReturnCode>`

        ::

            rc = DEV1.UIWaitForToastPopup(u"설정이 저장되었습니다.")
            if rc != AT_SUCCESS: 
                System.Finish(ExecutionResult.T_FAILED, "Toast Popup did not appear")

        """
        # 오브젝트 찾기
        rc, result = self.UIWaitForName(searchingObj, waitTimeout, UITarget.All)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForName")
            return rc
             
        if result == False:
            System.Debug(u"Failed to find the object : "+searchingObj)
            return AT_UI_CONTROL_NOT_FOUND
        
        # 오브젝트의 텍스트 속성 얻기
        rc, result = self.UIGetObjectByName(searchingObj, UITarget.All)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIGetObjectByName")
            return rc
        
        if result.Text != text:
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    @API()
    def ClearAppData(self):
        rc, result = self.SendAdbCommand("shell pm clear com.uplus.onphone")
        if rc != AT_SUCCESS:
            System.Debug("Cannot access shell")
            return rc
        System.Sleep(4000)
        return AT_SUCCESS
    
    @API()
    def ClearAppDataAgree(self):
        System.Sleep(5000)
        
        rc = self.UIClickByName("rlNext")
        if rc != AT_SUCCESS:
            System.Debug("Cannot access shell")
            return rc
        
        System.Sleep(3000)
        
        
        """
        rc = self.UIClickByName("permission_allow_button")
        if rc != AT_SUCCESS:
            System.Debug("Cannot access shell")
            return rc
            
        System.Sleep(3000)
        
        rc = self.UIClickByName("permission_allow_button")
        if rc != AT_SUCCESS:
            System.Debug("Cannot access shell")
            return rc
        System.Sleep(3000)
        
        rc = self.UIClickByName("permission_allow_button")
        if rc != AT_SUCCESS:
            System.Debug("Cannot access shell")
            return rc
        """
        
        rc = DEV1.UIClickByTypeIndex('avwButton', 9001)
        
        rc = DEV1.UIClickByTypeIndex('avwButton', 9001)
        
        rc = DEV1.UIClickByTypeIndex('avwButton', 9001)
    
            
            
        rc, result = DEV1.UIWaitForName("tvTitle", 3000)
        if rc != AT_SUCCESS:  # API가 성공적으로 수행되었는지 확인
            return rc
        
        if result == False:   # 텍스트가 나타났는지 확인
            return AT_NOT_FOUND
        
        
        rc = DEV1.UIClickByTypeIndex('avwCheckBox', 9000)
        """if rc != AT_SUCCESS:
            return rc   """
            
        System.Sleep(2000)
        
        rc = DEV1.UIClickByTypeIndex('avwSubWindow', 9014)
        """if rc != AT_SUCCESS:
            return rc   """
            
        rc, result = self.UIWaitForName("dialog_confirm_btn", 30000)
        if rc != AT_SUCCESS:
            System.Debug(u"Fail to UIWaitForName")
            return rc
             
        if result == False:
            System.Debug(u"Failed to find the object : dialog_confirm_btn")
            return AT_UI_CONTROL_NOT_FOUND
        
        rc = self.UIClickByName("dialog_confirm_btn")
        """if rc != AT_SUCCESS:
            return rc """  
            
        
        System.Sleep(5000)
       
        
        return AT_SUCCESS


    
    @API()
    def SetDataNetworkUsageCheckBox(self):
        """
        :summary: 
            데이터 네트워크 사용 안내 팝업 에서 다시보지 않기 체크 박스에 체크표시
        """  
        checkBoxIdx = 9000
        expectedState = False
        rc, result = DEV1.UICheckCheckboxByIndex(checkBoxIdx, expectedState)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UICheckCheckboxByIndex")
            return rc
        
        if result == False:
            System.Debug(u"Checkbox is NOT expected state [%s]"%str(expectedState))
            return AT_ERROR
        
        return self.UIClickByTypeIndex("avwCheckBox", checkBoxIdx)
    
   
    @API()
    def CheckLastestTVTextShown(self, waitTimeout = 3000):
        """
        :summary: 
            최신 방송 텍스트가 표시되었는지 확인
            실행 경로: 메인화면 => 스크롤 다운
        """  
        '''
        type: avwStaticText
        name: paperTitle1
        text: 최신 방송
        index: 9005
        '''
        searchingText = u"최신/인기 방송"
        rc, result = self.UIWaitForText(searchingText, waitTimeout, 0, UITarget.TopWindow)
        if rc != AT_SUCCESS:
            System.Debug(u"Failed to UIWaitForText")
            return rc
        
        if result == False:
            System.Debug(u"Failed to find the text : "+searchingText)
            return AT_NOT_FOUND
        
        return AT_SUCCESS
    
    
    def _getImagePath(self):
        outputPath = System.GetSystemPath(PATH_TEST_OUTPUT) 
        testScriptName = os.path.splitext(__builtins__['Context'].Config.Scenario)
        return os.path.join(outputPath, testScriptName[0])
    
    # No Reference
    @API()
    def CaptureFullScreenWithoutIndicator(self, imgName, delay=0):
        rc, result = self.UIGetObjectByName('rootlayout')
        if rc != AT_SUCCESS:
            return rc
        
        testScriptName = self._getImagePath()
        storeFileName =  testScriptName + '__{:0>2}'.format(self.count) + "_" + imgName + ".png"
        DEV1.CaptureScreen(result.Top, result.Left, result.Width, result.Height, storeFileName)
    
    
    
    @API()
    def StoreImage(self, imgName, delay=0):
        """
        :summary:
            현재의 화면 전체 이미지 저장

        :param imgName: 이미지명
        :type  imgName: str
        
        :param delay: 화면 저장을 수행하기 전 대기시간
        :type  delay: int, millisecond 단위


        :returns: No return

        :see: :class:

        ::

            rc = DEV1.StoreImage(u"MainMenuDisplay", 3000)

        """
        
        
        # outputPath = 테스트 로그 저장될 폴더 
        #  Test Node 수행시: 이 테스트를 수행하는 이클립스 workspace내에 테스트 프로젝트의 output 폴더
        #   ex) C:\Users\miae\workspace\UPlus_VideoPortalAPP_Test\output       
        #  Test Manager를 통한 수행시: C:\ATS5PE\Output
        outputPath = "C:/Program Files (x86)/LGERP/ATS 7.0/Modules/ATS/testnode/connectivity/static/"
        testScriptName = os.path.splitext(__builtins__['Context'].Config.Scenario)
        
        
        
        #print(outputPath)
        # 이미지 파일 명: 테스트 시나리오 파일명__전달된 이미지명.png
        #  ex) TC_58_59_60__기본표시메뉴.png
        
        filenameonly = testScriptName[0] + "__" + imgName + ".png"
        storeFileName = os.path.join( outputPath ,filenameonly)
        self.CaptureFullScreen(storeFileName)
        self.count += 1 
        
        System.Debug("<br><img src=http://localhost:8888/static/{} width=300><br>".format(filenameonly))
        
        
    @API()
    def ScreenVideoRecord(self, imgName, second=10):
       
        System.Debug(u"현재 화면 녹화 시작")
        
        
        
        outputPath = "C:/Program Files (x86)/LGERP/ATS 7.0/Modules/ATS/testnode/connectivity/static/"
        testScriptName = os.path.splitext(__builtins__['Context'].Config.Scenario)
        
        filenameonly = testScriptName[0] + "__" + imgName + ".mp4"
        
        storeFileName = os.path.join( outputPath ,filenameonly)
        
        rc = self.ScreenVideoRecordStart(storeFileName, second) #Record maximum 2 minutes with 2Mbs
        if rc == AT_SUCCESS:
            System.Debug(u"녹화가 성공적으로 시작됨.")
        
        else :  # API가 성공적으로 수행되었는지 확인
            System.Debug( u"녹화가 시작되지 않음.")
            
        System.Debug( str(second) + u"초를 기다린다.")
        sleepSecond = second * 1000
        System.Sleep(sleepSecond)
        
        videoHtml = "<br><video id=\"video1\"width=\"320\"height=\"500\"data-src=\"http://localhost:8888/static/\"controls style=\"margin-bottom:50px;\"autoplay\"loop=\"loop\">".format(filenameonly)
        videoHtml +="    <source src=\"http://localhost:8888/static/\"type=\"video/mp4\">".format(filenameonly)
        videoHtml +="</video>"
        
        System.Debug(videoHtml)
        
        self.ScreenVideoRecordStop()
        
        
        
        
        
        
    """@API()
    def StoreImage(self, imgName, delay=0):
        
        :summary:
            현재의 화면 전체 이미지 저장

        :param imgName: 이미지명
        :type  imgName: str
        
        :param delay: 화면 저장을 수행하기 전 대기시간
        :type  delay: int, millisecond 단위


        :returns: No return

        :see: :class:

        ::

            rc = DEV1.StoreImage(u"MainMenuDisplay", 3000)

        
        System.Sleep(delay)
        value = self.Context.Config.Mappings.values()
        model = value[0].Device.Model
        
        now = datetime.now()
        
        nowDate = '%s-%s-%s' % (now.year, now.month , now.day)
        
        # outputPath = 테스트 로그 저장될 폴더 
        #  Test Node 수행시: 이 테스트를 수행하는 이클립스 workspace내에 테스트 프로젝트의 output 폴더
        #   ex) C:\Users\miae\workspace\UPlus_VideoPortalAPP_Test\output       
        #  Test Manager를 통한 수행시: C:\ATS5PE\Output
        outputPath = System.GetSystemPath(PATH_TEST_OUTPUT) 
        testScriptName = os.path.splitext(__builtins__['Context'].Config.Scenario)
        
        dirname = outputPath+ "\\" +nowDate+'_'+model
        if not os.path.isdir(outputPath+ "\\" +nowDate+'_'+model): 
            os.mkdir(outputPath+  "\\"  +nowDate+'_'+model) 

        
        #print(outputPath)
        # 이미지 파일 명: 테스트 시나리오 파일명__전달된 이미지명.png
        #  ex) TC_58_59_60__기본표시메뉴.png
        storeFileName = os.path.join( outputPath ,dirname ,testScriptName[0] + "__" + imgName + ".png")
        self.CaptureFullScreen(storeFileName)
        self.count += 1 
        
        #System.Debug("<br><img src=http://localhost:8888/static/{} width=300><br>".format(storeFileName))
    """
    
    """@API()
    def StoreImage(self, imgName, delay=0):
        :summary:
            현재의 화면 전체 이미지 저장

        :param imgName: 이미지명
        :type  imgName: str
        
        :param delay: 화면 저장을 수행하기 전 대기시간
        :type  delay: int, millisecond 단위


        :returns: No return

        :see: :class:

        ::

            rc = DEV1.StoreImage(u"MainMenuDisplay", 3000)

        System.Sleep(delay)
        
        # outputPath = 테스트 로그 저장될 폴더 
        #  Test Node 수행시: 이 테스트를 수행하는 이클립스 workspace내에 테스트 프로젝트의 output 폴더
        #   ex) C:\Users\miae\workspace\UPlus_VideoPortalAPP_Test\output       
        #  Test Manager를 통한 수행시: C:\ATS5PE\Output
        outputPath = System.GetSystemPath(PATH_TEST_OUTPUT) 
        testScriptName = os.path.splitext(__builtins__['Context'].Config.Scenario)

        value = self.Context.Config.Mappings.values()
        model = value[0].Device.Model
        
        # 이미지 파일 명: 테스트 시나리오 파일명_캡처된순서번호_전달된 이미지명.png
        #  ex) TC_58_59_60__01_기본표시메뉴.png
        storeFileName = os.path.join(outputPath, testScriptName[0] + '__{:0>2}'.format(self.count) + "_" + imgName + ".png")
        self.CaptureFullScreen(storeFileName)
        self.count += 1  
    """
    @API()
    def ScrollUp(self, objType, index, ratio=0.9):
        return self._Scroll(objType, index, "up", ratio)
    
    @API()
    def ScrollDown(self, objType, index, ratio=0.9):
        return self._Scroll(objType, index, "down", ratio)
    
    @API()
    def ScrollRight(self, objType, index, ratio=0.9):
        return self._Scroll(objType, index, "right", ratio)
    
    @API()
    def ScrollLeft(self, objType, index, ratio=0.9):
        return self._Scroll(objType, index, "left", ratio)
    
    def _Scroll(self, objType, index, direction, ratio=1.5):
        rc, result = self.UIGetObjectByTypeIndex(objType, index)
        
        if rc != AT_SUCCESS:
            return rc
        
        left, right, top, bottom = result.Left, result.Left + result.Width, result.Top, result.Top + result.Height
        centerX, centerY = result.GetCenterCoords()
        
        if direction == "up":
            return self.TouchSlide(centerX, bottom - int((bottom-top)*ratio), centerX, bottom, 10, 40) #centerY -> bottom - (bottom-top)*ratio
        elif direction == "down":
            return self.TouchSlide(centerX, top + int((bottom-top)*ratio), centerX, top, 10, 40) # centerY -> top + (bottom-top)*ratio
        elif direction == "right":
            return self.TouchSlide(left + int((right-left)*ratio), centerY, left, centerY, 10, 40) # centerX -> left + (right-left)*ratio
        elif direction == "left":
            return self.TouchSlide(right - int((right-left)*ratio), centerY, right, centerY, 10, 40) # centerX -> right - (right-left)*ratio
        else:
            return AT_INVALID_PARAMETERS    


class Constants:
    MYFREE_SUBTAB_CNT = 7

    
# 각 경우에 대한 Timeout 상수값 정의      
class Timeout:
    WAIT_POPUP = 5000
    
                